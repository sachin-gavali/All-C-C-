#include<iostream>
using namespace std;
int main()
{
    int i;
    for (i=0;i<=5;i++)
    {
        cout << " *  " ;

    return 0;

        }
    
    
}