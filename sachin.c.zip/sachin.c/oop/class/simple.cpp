#include<iostream>
using namespace std;
class demo
{
    public:
    void display()
    {
        cout << "  \t SACHIN GAVALI " << endl;
        cout << " \t  WELCOME IN OOP " << endl;
    }

    };
 int  main()
  {
    demo d;
    d.display();
   return 0;
    
}