#include<iostream>
#include<conio.h>
using namespace std;
int main()
{
    int a ;
    cout<<"ENTER THE  NUMBER \n";
    cin>>a;
    for (int i=0;i<=10;i++)

    {
        for (int j = 0; j < i; j++)
        {
            cout<<i;
            
        }
    cout<<"\n";

    }
    return 0;

}