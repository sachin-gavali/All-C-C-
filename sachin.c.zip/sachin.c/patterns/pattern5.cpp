#include<iostream>
using namespace std ;

int main()
{
    int x;
    cout <<"ENTER THE NUMBER \n";
    cin>> x;
    for (int i = 0; i < x; i++)
    {
        for (int j=0; j< x; j++)
        {
            cout<< j ;
        }
        
           
           cout<< "\n";
    }

           return 0;

}                