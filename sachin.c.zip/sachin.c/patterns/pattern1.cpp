
#include<iostream>
using namespace std;
int main()
{ 
    int i;

    cout<< "ENTER THE NUMBER \n ";
    cin>> i;
    for (int  i = 0; i < 5; i++)
    {
        for (int  j = 0; j < 5; j++)
        
       {
           cout<< "*";
       
       }     
        
        cout<< "\n";
    }
   

    return 0;
}







