#include<bits/stdc++.h>
#include<iostream>
using namespace std;
void name ();
int main()
{
 cout <<" SACHIN GAVALI  ";
 name();
 return 0;

}
void name ()
{
    cout<<"JONATHAN \n";

}