#include<iostream>

using namespace std ;
int main () 
{
   for ( int a =0; a <= 5 ; a++ )
    {
        for(int i = 0 ; i <= 5 ; i++ )
        
         cout<< "* " ;


    }
     cout << endl; 
     return 0;
      
}