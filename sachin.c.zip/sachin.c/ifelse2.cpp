#include<iostream>
using namespace std;
int main ()
{
    int a;
    int s;

    cout<< "enter the age \n";
    cin >>s;
    cout<< "enter the age \n";
    cin >>a;
    if (s<150|| a<150)

    {
        if (s<18 || a<18)
        {
            cout<<"YOU CAN'T VOTE\n || YOU CAN'T DRIVE CAR\n";
        }
        else
        {
            cout<<"YOU CAN VOTE\n || YOU CAN  DRIVE A CAR\n";
            }   
            }    
        else
        {
            cout<< "YOU ARE CAN'T VOTE\n || YOU CAN'T DRIVE\n";

        }

                
        return 0;
    
}