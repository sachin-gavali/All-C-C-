#include<iostream>

using namespace std ;
int main () 
{
    int arr [6] [6]= {1,2,3,4,5,6};
                      

    // for looops for row 
   for ( int a =0; a <= 5 ; a++ )
    {
        // for loops for col

                for(int i = 0 ; i <= 5; i++ )
      {

         cout<< arr[a];
         break;
         
         
      }
      
    
     cout << endl;
    } 
     return 0;
      
}