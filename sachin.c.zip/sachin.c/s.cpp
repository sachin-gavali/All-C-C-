#include<iostream.h>
#include<conio.h>
int main()
{
   std :: cout<<"HELLO" <<std::end1;
    return 