int sum1;
int a;
int b;

#include<iostream>
using namespace  std;
#define pi 3.14
float redius;
void add();
int sum();
int main ()
{
  
    cout<< " REDIUS TAKA :::";
    cin>>redius;
    cout<<"AREA  OF CIRCLE is ="<<pi*redius*redius << endl;
     add();
     sum();
     
    return 0;
    
}


void add ()
{
    int x=redius+redius;
    cout<<" \n Sum of redius \n"<< endl;
     cout<<x << endl;

}
int sum()
{
    cout<<" ENTER THE NUMBER \n";
    cin>>a;
    cout<<" ENTER THE NUMBER \n";
    cin>>b;
    int sum1 =a+b;
    cout << " THE SUM IS = " << sum1;
    return sum1;
}