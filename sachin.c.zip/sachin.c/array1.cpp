#include<iostream>
using namespece std;
int main()
{
    int num[5];
    int i,sum=0;
    for (i = 0; i <5; i++)

    {
        cout<<"ENTER THE VALUE" <<(i+1) <<"   ::: ";
        cin >> num[i] ;

    }
    cout << "\n The elements are :: ";
    for (size_t i = 0; i <5; i++)

    {
       cout << num[i];

    }
    return 0;

}