#include<iostream>
using namespace std;
int main()
{
    int i;
    cout<< "enter the number \n ";
    cin>>i;
    for ( i = 0; i < 15; i++)

    {
        cout<<"*" <<i;

    }
    return 0;


}