{
    "configurations": [
        {
            "name": "windows-gcc-x86",
            "includePath": [
                "C:\\MinGW\\lib"
            ],
            "compilerPath": "C:\\Program Files (x86)\\mingw-w64\\i686-8.1.0-win32-sjlj-rt_v6-rev0\\mingw64\\bin\\g++.exe",
            "cStandard": "${default}",
            "cppStandard": "${default}",
            "intelliSenseMode": "windows-gcc-x86",
            "compilerArgs": []
        },
        {
            "name": "c++",
            "includePath": [
                "${workspaceFolder}/**"
            ],
            "defines": [
                "_DEBUG",
                "UNICODE",
                "_UNICODE"
            ],
            "compilerPath": "C:\\MinGW\\bin\\gcc.exe",
            "cStandard": "gnu11",
            "cppStandard": "gnu++14",
            "intelliSenseMode": "windows-gcc-x86"
        }
    ],
    "version": 4
}