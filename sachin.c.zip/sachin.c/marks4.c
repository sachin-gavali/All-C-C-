#include<stdio.h>
#include<conio.h>
#define pi 3.14

int main()
{
    float redius;
    printf("Enter the  redius\n");
    scanf("%f", & redius);
     printf("AREA OF CIRCLE =%f " ,pi*redius*redius);
    return 0;

}