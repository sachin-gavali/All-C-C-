#include<iostream>
using namespace std ;

int main()
{
    int a = 1;
    while (a<= 10)
    {
        cout << a ;
        a++ ;

    }cout << "\n ";

}