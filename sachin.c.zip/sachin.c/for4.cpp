#include<iostream>
using namespace std;
int main ()
{
    int x,s;
for (size_t i = 0; i <5; i++)
{
    for ( s = 0; s <=i; s++)

    cout<<i;

}
return 0;

}