#include<iostream>
int main()
{
   cout<<"HELLO world.";
    return 0;
}
