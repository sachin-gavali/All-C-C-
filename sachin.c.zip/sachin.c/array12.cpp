#include<isotream>
using namespece std;
int main()
{
    int a [2][2] = {3,4}
}