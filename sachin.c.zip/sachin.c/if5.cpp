#include<iostream>
using namespace std;
int main ()
{
    int r ;
    std::cout << "ENTER THE NUMBER \n " << std::endl;
    cin>> r;
    if (r<10)
    {
        cout<<"YOU SELECTED NUMBER IS UNDER THE 10 \n";
    }
    return 0;

}