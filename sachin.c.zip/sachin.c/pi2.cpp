#include<iostream>
using namespace  std;
#define pi 3.14

int main ()
{
    float redius;
    cout<< " REDIUS TAKA :::";
    cin>>redius;
    cout<<"AREA  OF CIRCLE is ="<<pi*redius*redius;
    return 0;
    
}
