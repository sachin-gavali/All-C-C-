#include<iostream>
using namespace std;
int main ()
{
    int a;
    cout<< "enter the age \n";
    cin >>(int s);
    return 0;
    
}