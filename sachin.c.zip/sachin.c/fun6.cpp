int sachin();
#include<iostream>
using namespace std;


int main()
{
    cout << " SACHIN GAVALI \n";
    sachin();
    
    return 0;

}
int sachin (int)
{   int a=10;
    int b=8;
    int sum= a+b;
    cout<<" sum = " << sum;
    return sum;
}