#include<iostream>

using namespace std;
int main()
{
    int i;
    cout<<"ENTER THE NUMBER \n";
    cin>>i;
    while (i<=15)
    {
       cout<< "JONATHAN";

    }
    return 0;
        

}

