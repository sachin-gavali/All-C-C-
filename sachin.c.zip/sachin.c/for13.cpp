#include<iostream>

using namespace std ;
int main () 
{
    // for looops for row 
   for ( int a =0; a <= 5 ; a++ )
    {
        // for loops for col

                for(int i = 0 ; i <= a; i++ )
      {

         cout<< "* ";
      }
      
    
     cout << endl;
    } 
     return 0;
      
}