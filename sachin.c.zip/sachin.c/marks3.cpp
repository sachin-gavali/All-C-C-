
#include<iostream>
using namespace std;
 
     
     int main()
     {
         int marks;
         cout<< "ENTER YOUR TOTAL MARKS \n";
         cin>> marks;
         
     
        if (marks>=80)
        {
            cout<<"\n GRADE= A+ ";
             }
             else if (marks>=70)
             {
                 cout<<"\n GRADE = A";
                }  
                 else if (marks>=60)
             {
                 cout<<"\n GRADE = B+";
                  } 
                   else if (marks>=50)
             {
                 cout<<"\n GRADE = B";
                     }
                      else if (marks>=40)
             {
                 cout<<"\n GRADE = C";
             }
         else
         {
             cout<< "\nYOU ARE FAIL IN 1st SEM";

         }
         return 0;
 }   