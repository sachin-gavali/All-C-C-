#include<bits/stdc++.h>
#include<iostream>
#include <conio.h>
using namespace std;
void name ();
int day();
int age();
int main()
{
 cout <<" SACHIN GAVALI \n ";
 name();
 day();
 age();
 return 0;

}
void name (void)
{
    cout<<" \t ______HAPPY  VELENTINE DAY _____\n";

}
int day (int )
{
    int days;
    cout << " \t ENTER THE DATE \n";
    cin>> days;
    switch (days)
    {
        case 7:
        cout<< " ROSE DAY \n";
        break;
        case 8:
        cout<< " ROSE DAY \n";
        break;
        case 9:
        cout<< " ROSE DAY \n";
        break;
        case 10:
        cout<< " ROSE DAY \n";
        break;
        case 11:
        cout<< " ROSE DAY \n";
        break;
        case 12:
        cout<< " ROSE DAY \n";
        break;
        case 13:
        cout<< " ROSE DAY \n";
        break;
        case 14:
        cout<< " ROSE DAY \n";
        break;
    
    default:
         cout<< " Day choose in 7-14 \n";
        break;
    }
    

}

int age (int )
{
    int a;
    cout<< "ENTER THE YOUR AGE \n";
    cin>> a;
    if (a<=17)
    {
        cout<< " YOU CAN'T CELEBRATE \n";
    }
    else if (a=18)
    {
        cout<<"___________Single __________";
    }
    else
    {
        cout<<" YOU CAN CELEBRTE \n";
    }
    

    
        
    
}