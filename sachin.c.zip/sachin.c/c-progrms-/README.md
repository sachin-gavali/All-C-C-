# c progrms 
 simples progrgms 
