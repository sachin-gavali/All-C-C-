#include<iostream>
#include<conio.h>
using namespace std;
void  name1();

int main ()
{
    cout <<"SACHIN GAVALI " ;
    name1();
    return 0;

}
void name1 ()
{
    cout<<" \n GAVALI SACHIN";
    

}