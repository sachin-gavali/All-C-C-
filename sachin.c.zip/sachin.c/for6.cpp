#include<iostream>
using namespace std;
int main()
{
    int r ;
    for (int  i = 0; i < 10; i++)
    {
        cout<<"SACHIN\n ";
        
    }
    return 0;

}