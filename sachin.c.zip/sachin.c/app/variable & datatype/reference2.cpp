#include<iostream>
using namespace std ; 
int main()
{
    double v =100000;
    long double f = 102.456;
    double& s=v;
    long double& g=f;

    cout<<"the value of v" << v<< endl;
    cout<<"the value of s" << s<< endl;



    cout<<"the value of f " << f<< endl;
    cout<<"the value of g" << g<< endl;
return 0;


    
}