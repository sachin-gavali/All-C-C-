#include<iostream>
using namespace std;
typedef int integer;
typedef float real;
int main()
{
 integer a = 34;
 real b = 67;
 cout << "\n a = " << a << "\n b = " << b << endl;
 return 0;

}