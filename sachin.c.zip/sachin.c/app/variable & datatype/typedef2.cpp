#include<iostream>
using namespace std;
typedef int sachin;
typedef float gavali;
typedef char x;
typedef double cutee;
typedef long sweety;
int main()
{
    sachin a =10;
    gavali b= 203.345;
    x c = 's';
    cutee  d= 100.4542;
    sweety  e= 467484;
    cout << " \n value of  a = "<< a  << "\n" << sizeof(sachin)<< endl;
    cout << " \n value of  b = "<< b <<  "\n" <<sizeof(gavali)<< endl;
    cout << " \n value of  c= "<< c  << "\n"  << sizeof(x)<< endl;
    cout << " \n value of  d = "<< d<< "\n "  <<sizeof(cutee)<< endl;
    cout << " \n value of  e = "<< e<< "\n"  <<sizeof(sweety)<< endl;
    return 0;


}