#include<iostream>
using namespace std ;
 int main()
 {
      double float redius = 10.00;
      double float hight = 20.00;

       double float volume = 3.143*redius* hight * redius ;
      cout << " THE VOLUME IS " << volume << endl;
      return volume;
      
 }