#include<iostream>
using namespace std ;
 int main()
 {
      double  redius = 10.00;
      double hight = 20.00;

       double  volume = 3.143*redius* hight * redius ;
      cout << " THE VOLUME IS " << volume << endl;
      return volume;
      
 } 