// 5 chaa padha  

#include<iostream>
using namespace std;
int main()
{
    int n;
    cout << "ENTER A NUMBER \n "<< endl;
    cin >> n;
    for(int a = 1 ; a <= n ; a++)\
    {
        a= a+4;
        cout << "the number is  = "<< a << ' ' << endl;

    }
    return 0;

}