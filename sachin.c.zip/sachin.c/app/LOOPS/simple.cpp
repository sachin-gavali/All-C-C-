// all even number 

#include<iostream>
using namespace std;
int main()
{
    int n;
    cout << "ENTER A NUMBER \n "<< endl;
    cin >> n;
    for(int a = 1 ; a <= n ; a++)\
    {
        a= a+1;
        cout << "the number is  = "<< a << ' ' << endl;

    }
    return 0;

}