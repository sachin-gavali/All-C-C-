#include<iostream>
using namespace std;
int main ()
{
     int n,r;
    cout << " ENTER THE ANY NUMBER   :: " << endl;
    cin >> n;
   long int  sum = 0 ;
   while (n != 0)
   {
       r = n%10;
       sum = sum +r ;
       
   }
   cout << " the sum of the digits is = " << sum << endl;
   return 0;


}