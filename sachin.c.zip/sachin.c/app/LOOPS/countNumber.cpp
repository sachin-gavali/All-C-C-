#include<iostream>
using namespace std;
int  main()
{
    long int n ,c ;
    cout<< "\n Enter a positive number :: ";
    cin >> n;
    c=0 ;
    while (n != 0 )
    {
        n = n/10;
        c=c+1;

    }
    cout<< " The number of the digits  is  = " << c << endl;
   return 0;

}