#include<iostream>
using namespace std ; 
int main ()
{
     int redius = 20 ;
     cout << " THE REDIUS IS = "  ;
     cout << redius;
     return redius;
     

}