#include<iostream>
using namespace std ;
int main()
{
    int  a,s,d;
    cout <<" Enter the two number \n ";
    cin>> a >> s ;
    cout<< "  value of a = \n" << a <<  "value of  s \n=" <<s << endl;
    d=a;
    a=s;
    s=d;
    cout << "  value of a = \n" << a << " value of s \n "<< s << endl;
    return 0;
    
}