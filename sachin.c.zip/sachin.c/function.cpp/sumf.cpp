#include<iostream>
using namespace std;
{
  int sum;
  cout<< "ENTER THE NAME \n";
  cin>>(char name);
  return 0;
    
} 
