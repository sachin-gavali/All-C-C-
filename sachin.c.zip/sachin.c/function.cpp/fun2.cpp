#include<iostream>
using namespace std;
int main()
{
    int x;
    cout << "enter the a number \n";
    cin>>x;
    for(x=1;x<=10;x++)
    
    {
        cout<<"S\n";

    }
    return 0;

}