#include<iostream>
using namespace std;
int main()


{
  int sum;
  char name;
  cout<< "ENTER THE NAME \n";
  cin>>name;
  if (a>100 || a<110)
  {
    if (a)
    {
      /* code */
    }
    




    std::cout << "FULL MARKS" << std::endl;

  }

  
  return 0;
    
} 
