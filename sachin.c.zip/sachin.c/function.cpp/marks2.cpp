#include<iostream>
using namespace std;
 int main() 
 {
     int x;
     
     cout<<"ENTER YOUR NAME \n"<<endl;
     cin>>(char name);
     cout<<"ENTER YOUR AGE OR ROLL NUMBER  \n"<<endl;
     cin>>(char age ,roll);

    return 0;
}