#include<iostream>
using namespace std;

int main()
{
    int num[5] ={3,4,5,6,7};
    cout<< "The number are \n";
    for(int i =0; i<=5;i++)
    cout<<"the number is \n" << num[i] ;
    return 0;

}