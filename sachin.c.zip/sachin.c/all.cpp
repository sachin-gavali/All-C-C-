int s,d;
#include<bits/stdc++.h>
#include<iostream>
using namespace std;
void name ();
int arr();
void dash();
int day();
int age();
int main()
{
 cout <<" SACHIN GAVALI \n ";
 age();
 dash();
 day();
 dash();
 day();
 dash();
 name();
 dash();
 arr();
 
 return d;

}
void name ()
{
    cout<<" \t ______HAPPY VELENTINE DAY_____\n";

}
int day ()
{
    int days;
    cout << " \n ENTER THE DATE \n";
    cin>> days;
    switch (days)
    {
        case 7:
        cout<< " ROSE DAY \n"; 
        break;
        case 8:
        cout<< " ROSE DAY \n";
        break;
        case 9:
        cout<< " ROSE DAY \n";
        break;
        case 10:
        cout<< " ROSE DAY \n";
        break;
        case 11:
        cout<< " ROSE DAY \n";
        break;
        case 12:
        cout<< " ROSE DAY \n";
        break;
        case 13:
        cout<< " ROSE DAY \n";
        break;
        case 14:
        cout<< " ROSE DAY \n";
        break;
    
    default:
         cout<< " Day choose in 7-14 \n";
        break;
    }
return s;
}

int age ()
{
    int a;
    cout<< "ENTER THE YOUR AGE \n";
    cin>> a;
    if (a<17)
    {
        cout<< " YOU CAN'T CELEBRATE \n";
    }
    else if (a>=19)
    {
        cout<<" YOU CAN CELEBRTE \n";
    }
    
    else
    {
        cout<<"  ________SINGLE________\n";
    }
    

    return 0;
        
    
}
void  dash()
{
    for(int i = 0; i<= 15; i++)
    {
        cout << "__";
 }
 
}
int arr()
{
    int i;

    int sachin[5] = {11,12,13,14,15};

    for(int i = 0;  i<=4;  i++ )

    cout<< " \n "<< sachin[i] << endl;

    cout << sachin [0] << endl;

    cout << sachin [3] << endl;

    cout << sachin [1] << endl;

    cout << sachin [2] << endl;

    return i;

}