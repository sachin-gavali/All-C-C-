#include<iostream>
using namespace std;
int main()
{
    int num [4]={4,5,6,7};
    cout << "THE NUMBER IS ";
    
    for(int i =0; i<=4; i++)
    cout<<"\n the number is "<<" \n "<< num[i] ;
    return 0;

}